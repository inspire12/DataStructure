package mazeOfmemory;

public class TestmazeOfmemory {
	
	public static void main(String[] args) {
		AppController _appController = new AppController();
		_appController.run();
	}
	
}
