package mazeOfmemory;

public interface mazeBoard {
	void set();
	
}
