package mazeOfmemory;

public class player {

	private int _xlocation;
	private int _ylocation;
	public player(){

	}
	public player(int x,int y){
		set_xlocation(x);
		set_ylocation(y);
	}
	public int get_xlocation() {
		return _xlocation;
	}
	public void gohome1(){
		set_xlocation(0);
		set_ylocation(0);
	}
	public void set_xlocation(int _xlocation) {
		this._xlocation = _xlocation;
	}
	public int get_ylocation() {
		return _ylocation;
	}
	public void set_ylocation(int _ylocation) {
		this._ylocation = _ylocation;
	}

	private int currentLocation(){
		return 0;
	}
	private void ismove(){
		
	}
	public boolean moveLeft(){
		//�����̼��� 7�� ������(���� �Ѿ�� �ȵ�)
		this._xlocation--;
		if(this._xlocation<0){gohome1();return false;}
		return true;
	}
	public boolean moveRight(){
		this._xlocation++;
		if(this._xlocation>6){gohome1();return false;}//�� ���� �°� ����
		return true;
	}
	public boolean moveUp(){
		this._ylocation++;
		if(this._ylocation>6){gohome1();return false;}
		return true;
	}
	public boolean moveDown(){
		this._ylocation--;
		if(this._ylocation<0){gohome1();return false;}
		return true;

	}
	
	private void meetWallgotoStart(){
		
	}


}
