package mazeOfmemory;

public class mazeBoard2 implements mazeBoard{
public mazeBoard2() {
	// TODO Auto-generated constructor stub
}

@Override
public void set() {
	// TODO Auto-generated method stub
	
}
}
